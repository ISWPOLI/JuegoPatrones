package Juego_GUI;

import javax.swing.AbstractButton;
import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Random;

import javax.swing.JTextArea;

import java.awt.BorderLayout;
import java.awt.CardLayout;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.JScrollPane;

public class FramePreg1 extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private int numero;
	public Icon icono;



	/**
	 * Create the frame.
	 */
	public FramePreg1() {
		setTitle("Pregunta 1");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 622, 489);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		P1 p = new P1("/Juego_GUI/quien-quiere-ser-millonario.jpg");					
		p.setBounds(0, 0, 606, 317);
		getContentPane().add(p);
		p.setLayout(null);


		JButton Ayuda_llamada = new JButton("");
		Ayuda_llamada.setIcon(new ImageIcon(FramePreg1.class.getResource("/Juego_GUI/Telefono.jpg")));
		Ayuda_llamada.setBounds(10, 61, 67, 35);
		p.add(Ayuda_llamada);

		JButton Ayuda_publico = new JButton("");
		Ayuda_publico.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					ayudaPublico(numero);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		Ayuda_publico.setIcon(new ImageIcon(FramePreg1.class.getResource("/Juego_GUI/Publico.jpg")));
		Ayuda_publico.setBounds(10, 114, 67, 35);
		p.add(Ayuda_publico);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 321, 596, 40);
		contentPane.add(scrollPane);

		JLabel lblTexto = new JLabel("texto");
		scrollPane.setViewportView(lblTexto);
		lblTexto.setHorizontalAlignment(SwingConstants.CENTER);


		final JButton btnBoton1 = new JButton("boton1");
		btnBoton1.setBounds(20, 372, 275, 28);
		contentPane.add(btnBoton1);

		final JButton btnBoton2 = new JButton("boton2");
		btnBoton2.setBounds(329, 372, 275, 28);
		contentPane.add(btnBoton2);

		final JButton btnBoton3 = new JButton("boton3");
		btnBoton3.setBounds(20, 411, 275, 28);
		contentPane.add(btnBoton3);

		final JButton btnBoton4 = new JButton("boton4");
		btnBoton4.setBounds(329, 411, 275, 28);
		contentPane.add(btnBoton4);

		numero = (int) (Math.random() * 14) + 1;
		final Pregunta pregunta = new Pregunta(numero);

		lblTexto.setText(pregunta.getDescripcion());
		btnBoton1.setText(pregunta.getRespuesta1());
		btnBoton1.addActionListener(new ActionListener() {			
			public void actionPerformed(ActionEvent arg0) {
				String [] array = pregunta.getid1().split("-");
				validarPregunta(array[0]);				
			}

		});
		btnBoton2.setText(pregunta.getRespuesta2());
		btnBoton2.addActionListener(new ActionListener() {			
			public void actionPerformed(ActionEvent arg0) {
				String [] array = pregunta.getid2().split("-");
				validarPregunta(array[0]);				
			}

		});
		btnBoton3.setText(pregunta.getRespuesta3());
		btnBoton3.addActionListener(new ActionListener() {			
			public void actionPerformed(ActionEvent arg0) {
				String [] array = pregunta.getid3().split("-");
				validarPregunta(array[0]);				
			}

		});
		btnBoton4.setText(pregunta.getRespuesta4());
		btnBoton4.addActionListener(new ActionListener() {			
			public void actionPerformed(ActionEvent arg0) {
				String [] array = pregunta.getid4().split("-");
				validarPregunta(array[0]);				
			}

		});

		JButton Ayuda_50_50 = new JButton("");
		Ayuda_50_50.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					ayuda50_50(numero,btnBoton1,btnBoton2,btnBoton3,btnBoton4);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}	
			}
		});
		Ayuda_50_50.setIcon(new ImageIcon(FramePreg1.class.getResource("/Juego_GUI/50-50.jpg")));
		Ayuda_50_50.setBounds(10, 10, 67, 35);
		p.add(Ayuda_50_50);
	}

	public void validarPregunta(String idRespuesta){

		MyDataAcces conexionBtn1 = new MyDataAcces();
		ResultSet resultado;
		resultado = conexionBtn1.getQuery("SELECT * FROM RESPUESTAS WHERE ID_RESPUESTAS = "+idRespuesta);
		String correct = "";
		try {
			while(resultado.next()){
				correct = resultado.getString("CORRECT_INCORR");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		if(correct.equals("C")){
			JOptionPane.showMessageDialog(null, "Respuesta Correcta");
			FramePreg1 pregunta1 = new FramePreg1();
			pregunta1.setVisible(true);
			FramePreg1.this.dispose();

		}else{
			JOptionPane.showMessageDialog(null, "�Lo sentimos! has perdido :(");
			FramePreg1.this.dispose();
		}
	}
	public void ayuda50_50(int idRespuesta, AbstractButton btnBoton1,AbstractButton btnBoton2,AbstractButton btnBoton3,AbstractButton btnBoton4) throws SQLException{

		MyDataAcces conexionBtn1 = new MyDataAcces();
		MyDataAcces conexionBtn2 = new MyDataAcces();
		MyDataAcces conexionBtn3 = new MyDataAcces();
		MyDataAcces conexionBtn4 = new MyDataAcces();

		ResultSet resultado;
		final Pregunta pregunta = new Pregunta(numero);
		String id1= pregunta.getid1();
		resultado = conexionBtn1.getQuery("SELECT CORRECT_INCORR FROM RESPUESTAS WHERE ID_RESPUESTAS = "+id1);
		String correct = "";
		while(resultado.next()){
			correct = resultado.getString("CORRECT_INCORR");
		}
		System.out.println(correct);
		if (correct.equals("C")){
			btnBoton2.setText("");	
			btnBoton3.setText("");
			this.getContentPane().repaint();
		}else{
			btnBoton1.setText("");	
			this.getContentPane().repaint();
			String id2= pregunta.getid2();
			resultado = conexionBtn2.getQuery("SELECT CORRECT_INCORR FROM RESPUESTAS WHERE ID_RESPUESTAS = "+id2);
			while(resultado.next()){
				correct = resultado.getString("CORRECT_INCORR");
			}
			if (correct.equals("C")){
				String id3= pregunta.getid3();
				resultado = conexionBtn3.getQuery("SELECT CORRECT_INCORR FROM RESPUESTAS WHERE ID_RESPUESTAS = "+id3);
				while(resultado.next()){
					correct = resultado.getString("CORRECT_INCORR");
				}
				if (correct.equals("C")){
					String id4= pregunta.getid4();
					resultado = conexionBtn4.getQuery("SELECT CORRECT_INCORR FROM RESPUESTAS WHERE ID_RESPUESTAS = "+id2);
					while(resultado.next()){
						correct = resultado.getString("CORRECT_INCORR");
					}
					if (correct.equals("C")){

					}else{
						btnBoton4.setText("");	
						this.getContentPane().repaint();
					}
				}else{
					btnBoton3.setText("");	
					this.getContentPane().repaint();
				}
			}else{
				btnBoton2.setText("");	
				this.getContentPane().repaint();
			}
		}
	}
	public void ayudaPublico(int IDPREGUNTA) throws SQLException {
		MyDataAcces conexionBtn1 = new MyDataAcces();		
		ResultSet resultado;
		resultado = conexionBtn1.getQuery("SELECT ID_RESPUESTAS FROM RESPUESTAS WHERE Fk_PREGUNTA = "+IDPREGUNTA+" AND CORRECT_INCORR='C'");
		String correct = "";
		while(resultado.next()){
			correct = resultado.getString("ID_RESPUESTAS");
		}
		System.out.println("El id es: "+correct);
		int valor= Integer.parseInt(correct);
		while (valor>4){
			if (valor%4==0){
				valor=4;
			}else if(valor==3){
				valor=3;
			}else if(valor==2){
				valor=valor-4;
			}else if(valor==1){
				valor=1;
			}else {
				valor=valor-4;
				}
		}		System.out.println("El id es: "+correct);

		switch (valor) {
		case 1:
			numero = (int) (Math.random() * 3) + 1;
			System.out.println(numero);
			switch (numero) {
			case 1:
				icono=new ImageIcon("Respuesta_A1.png");
				break;
			case 2:
				icono=new ImageIcon("Respuesta_A2.png");
				break;
			case 3:
				icono=new ImageIcon("Respuesta_A3.png");
				break;
			}
			break;
		case 2:
			numero = (int) (Math.random() * 3) + 1;
			System.out.println(numero);
			switch (numero) {
			case 1:
				icono=new ImageIcon("Respuesta_B1.png");
				break;
			case 2:
				icono=new ImageIcon("Respuesta_B2.png");
				break;
			case 3:
				icono=new ImageIcon("Respuesta_B3.png");
				break;
			}
			break;
		case 3:
			numero = (int) (Math.random() * 3) + 1;
			System.out.println(numero);
			switch (numero) {
			case 1:
				icono=new ImageIcon("Respuesta_C1.png");
				break;
			case 2:
				icono=new ImageIcon("Respuesta_C2.png");
				break;
			case 3:
				icono=new ImageIcon("Respuesta_C3.png");
				break;
			}
			break;
		case 4:
			numero = (int) (Math.random() * 3) + 1;
			System.out.println(numero);
			switch (numero) {
			case 1:
				icono=new ImageIcon("Respuesta_D1.png");
				break;
			case 2:
				icono=new ImageIcon("Respuesta_D2.png");
				break;
			case 3:
				icono=new ImageIcon("Respuesta_D3.png");
				break;
			}
			break;
		}
		Grafica grafica = new Grafica(icono);
		grafica.setVisible(true);
	}

	public Icon getIcono() {
		return icono;
	}

	public void setIcono(Icon icono) {
		this.icono = icono;
	}
}
