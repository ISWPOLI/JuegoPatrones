package Juego_GUI;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MyDataAcces {
	
	private String usuario = "root";
	private String password = "Poli123*";
	private static String bd = "juego";
	private String url = "jdbc:mysql://localhost:3306/"+bd;
	private Connection conn = null;
	
	public MyDataAcces(){
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = (Connection)DriverManager.getConnection(url, usuario, password);
			if(conn != null){
				System.out.println("Conexion a la base de datos ok");
			}
		} catch (SQLException ex) {
			System.out.println("No se pudo realizar la conexion a la BD");
			ex.printStackTrace();
		}catch (ClassNotFoundException e) {
			System.out.println(e);
		}
	}
	
	public ResultSet getQuery(String query){
		Statement state = null;
		ResultSet resultado = null;
		try {
			state = (Statement)conn.createStatement();
			resultado = state.executeQuery(query);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return resultado;
	}
	
	public void setQuery(String query){
		Statement state = null;
		try {
			state = (Statement)conn.createStatement();
			state.execute(query);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
