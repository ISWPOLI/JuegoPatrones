package Juego_GUI;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.Icon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.ImageIcon;

public class Grafica extends JFrame {

	private JPanel contentPane;
	/**
	 * Create the frame.
	 */
	public Grafica(Icon icono) {
		setBounds(100, 100, 466, 334);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 450, 295);
		contentPane.add(panel);
		panel.setLayout(null);
		FramePreg1 framePreg1 = new FramePreg1();
		Icon ruta=framePreg1.getIcono();
		System.out.println(icono);

		JButton btnNewButton = new JButton("");
		btnNewButton.setIcon(new ImageIcon(Grafica.class.getResource("/Juego_GUI/"+icono)));
		btnNewButton.setBounds(0, 0, 450, 293);
		panel.add(btnNewButton);
	}
}
