package Juego_GUI;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Fondo extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Fondo frame = new Fondo();
					frame.setVisible(true);
					frame.setSize(400,300);
					Panel_Principal p = new Panel_Principal("/Juego_GUI/quien-quiere-ser-millonario.jpg");					
					frame.getContentPane().add(p);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Fondo() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JButton btnEmpezarJuego = new JButton("Empezar Juego");
		btnEmpezarJuego.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				FramePreg1 pregunta1 = new FramePreg1();
				pregunta1.setVisible(true);
				Fondo.this.dispose();
			}
		});
		contentPane.add(btnEmpezarJuego, BorderLayout.SOUTH);
	}
}
