package Juego_GUI;

import java.sql.ResultSet;
import java.sql.SQLException;

public class Pregunta {
	
	private int id;
	private String descripcion;
	private String respuesta1;
	private String respuesta2;
	private String respuesta3;
	private String respuesta4;
	private String id1;
	private String id2;
	private String id3;
	private String id4;
	
	public Pregunta(int id_pregunta){
		MyDataAcces conexion = new MyDataAcces();
		ResultSet resultado;
		this.id = id_pregunta;		
		resultado = conexion.getQuery("SELECT * FROM PREGUNTAS WHERE ID_PREGUNTAS = "+id_pregunta);
		try {
			while(resultado.next()){
				this.descripcion = resultado.getString("DESCRIPCION");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		//LLENAR RESPUESTAS
		
		String[] respuestas = new String[4];
		String[] Ids = new String[4];
		ResultSet result;
		result = conexion.getQuery("SELECT * FROM RESPUESTAS WHERE FK_PREGUNTA = "+id_pregunta);
		try {
			int cont = 0;
			while(result.next()){
				respuestas[cont] =  result.getString("DESCRIPCION");
				Ids[cont] = result.getString("ID_RESPUESTAS");
				cont++;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		this.respuesta1 = respuestas[0];
		this.respuesta2 = respuestas[1];
		this.respuesta3 = respuestas[2];
		this.respuesta4 = respuestas[3];
		
		this.id1 = Ids[0];
		this.id2 = Ids[1];
		this.id3 = Ids[2];
		this.id4 = Ids[3];	
		
	}

	public int getId() {
		return id;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public String getRespuesta1() {
		return respuesta1;
	}

	public String getRespuesta2() {
		return respuesta2;
	}

	public String getRespuesta3() {
		return respuesta3;
	}

	public String getRespuesta4() {
		return respuesta4;
	}
	public String getid1() {
		return id1;
	}

	public String getid2() {
		return id2;
	}

	public String getid3() {
		return id3;
	}

	public String getid4() {
		return id4;
	}
}
