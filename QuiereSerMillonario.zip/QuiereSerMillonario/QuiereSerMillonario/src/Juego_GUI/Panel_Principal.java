package Juego_GUI;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class Panel_Principal extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	ImageIcon imagen;
	String nombre;
	
	
	public Panel_Principal(String nombre) {

		this.nombre = nombre;
		setLayout(new BorderLayout(0, 0));
				
	}
	public void paint(Graphics g){
		Dimension tamano= getSize();
		imagen = new ImageIcon(getClass().getResource(nombre));
		g.drawImage(imagen.getImage(),0,0,tamano.width,tamano.height,null);
		setOpaque(false);
		super.paint(g);
	}
	
}
