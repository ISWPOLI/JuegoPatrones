package dev.com.tilegame.world;

import java.awt.Graphics;

import dev.com.tilegame.Game;
import dev.com.tilegame.Handler;
import dev.com.tilegame.entity.EntityManager;
import dev.com.tilegame.entity.creatures.player.Player;
import dev.com.tilegame.entity.statics.Carta1;
import dev.com.tilegame.entity.statics.*;
import dev.com.tilegame.tiles.Tile;
import dev.com.tilegame.utils.Utils;

public class World {
	
	private Handler handler;
	private int width, height;
	private int spawnX, spawnY;
	private int [][] tiles;
	
	//Entities 
	private EntityManager entityManager;
	
	
	public World(Handler handler, String path){
		this.handler = handler;
		entityManager = new EntityManager(handler, new Player(handler, 100, 100));
		entityManager.addEntity(new Carta1(handler, 20, 20,0));
		entityManager.addEntity(new Carta1(handler, 150, 20,1));
		entityManager.addEntity(new Carta1(handler, 280, 20,2 ));
		entityManager.addEntity(new Carta1(handler, 410, 20,3));
		entityManager.addEntity(new Carta1(handler, 540, 20,4));
		entityManager.addEntity(new Carta1(handler, 20, 200,5));
		entityManager.addEntity(new Carta1(handler, 150, 200,6));
		entityManager.addEntity(new Carta1(handler, 280, 200,7));
		entityManager.addEntity(new Carta1(handler, 410, 200,8));
		entityManager.addEntity(new Carta1(handler, 540, 200,9));
		entityManager.addEntity(new Carta1(handler, 20, 380,10));
		entityManager.addEntity(new Carta1(handler, 150, 380,11));
		entityManager.addEntity(new Carta1(handler, 280, 380,12));
		entityManager.addEntity(new Carta1(handler, 410, 380,13));
		entityManager.addEntity(new Carta1(handler, 540, 380,14));
		entityManager.addEntity(new Carta1(handler, 20, 560,15));
		entityManager.addEntity(new Carta1(handler, 150, 560,16));
		entityManager.addEntity(new Carta1(handler, 280, 560,17));
		entityManager.addEntity(new Carta1(handler, 410, 560,18));
		entityManager.addEntity(new Carta1(handler, 540, 560,19));

		
		
		
		loadWorld(path);
		
		entityManager.getPlayer().setX(spawnX);
		entityManager.getPlayer().setY(spawnY);
		
	}
	
	public void tick(){
		entityManager.tick();
		
	}
	
	public void render(Graphics g){
		int xStart = (int)Math.max(0, handler.getGameCamera().getxOffset()/Tile.TILEWIDTH);
		int xEnd = (int) Math.min(width, (handler.getGameCamera().getxOffset() + handler.getWidth())/ Tile.TILEWIDTH +1);
		int yStart = (int) Math.max(0, handler.getGameCamera().getyOffset()/Tile.TILEHEIGHT);
		int yEnd = (int) Math.min(height, (handler.getGameCamera().getyOffset()+ handler.getHeight())/Tile.TILEHEIGHT +1);
		
		
		
		for (int y = yStart; y < yEnd; y++) {
			for (int x = xStart; x < xEnd; x++) {
				getTile(x, y).render( g, (int)(x*Tile.TILEWIDTH - handler.getGameCamera().getxOffset()), 
						(int) (y*Tile.TILEHEIGHT - handler.getGameCamera().getyOffset()));
				
			}
		}
		entityManager.render(g);
	}
	
	public Tile getTile(int x, int y){
		if(x<0 || y<0 || x >= width || y >= height)
			return Tile.Stonefloor;
		
		Tile t = Tile.tiles[tiles[x][y]];
		if (t == null)
			return Tile.CarpetTile;
		return t;
		
	}
	
	private void loadWorld(String path){
		String file = Utils.loadFileAsString(path);
		String[] tokens = file.split("\\s+");
		width = Utils.parseInt(tokens[0]);
		height  = Utils.parseInt(tokens[1]);
		spawnX = Utils.parseInt(tokens[2]);
		spawnY  = Utils.parseInt(tokens[3]);
		
		
		tiles = new int [width][height];
		
		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {
				tiles[x][y] = Utils.parseInt(tokens[(x+y *width)+4]);
			}
		}
		
		
		
		//test code
		/*
		width = 5;
		height = 5;
		tiles = new int[width][height];
		
		
		for (int x = 0; x <width; x++) {
			for (int y = 0; y < height; y++) {
				tiles[x][y] = 0;
				
			}
		}
	*/	
	}
	
	public int  getWidth(){
		return width;
		
	}
	
	public int getHeight(){
		return height;
	}

	public EntityManager getEntityManager() {
		return entityManager;
	}
	
	
}
