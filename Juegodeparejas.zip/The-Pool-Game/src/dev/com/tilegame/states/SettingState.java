package dev.com.tilegame.states;

import java.awt.Graphics;

import dev.com.tilegame.Game;
import dev.com.tilegame.Handler;

public class SettingState  extends States {

	
	public SettingState(Handler handler){
		super(handler);
		
	}
	@Override
	public void tick() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void render(Graphics g) {
		// TODO Auto-generated method stub
		
	}

}
