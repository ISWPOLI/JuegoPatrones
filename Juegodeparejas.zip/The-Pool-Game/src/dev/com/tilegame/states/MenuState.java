package dev.com.tilegame.states;

import java.awt.Graphics;

import dev.com.tilegame.Game;
import dev.com.tilegame.Handler;

public class MenuState extends States{

	
	public MenuState(Handler handler){
		super(handler);
	}
	
	public void tick() {
		
		
	}

	
	public void render(Graphics g) {
		
		
	}

}
