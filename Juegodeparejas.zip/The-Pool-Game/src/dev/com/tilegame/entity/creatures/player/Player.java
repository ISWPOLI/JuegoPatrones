package dev.com.tilegame.entity.creatures.player;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

import javax.swing.JOptionPane;

import dev.com.tilegame.Game;
import dev.com.tilegame.Handler;
import dev.com.tilegame.entity.Entity;
import dev.com.tilegame.entity.creatures.Creature;
import dev.com.tilegame.entity.statics.Carta1;
import dev.com.tilegame.gfx.Animation;
import dev.com.tilegame.gfx.Assets;


public class Player extends Creature {
	
	private static final Entity NULL = null;
	private Animation animationUp,animationLeft,animationDown,animationRight;
	public int id, contadorclicks=0;
	public Entity cartaClick2 = new Carta1(this.handler,0,0,0);
	public Entity cartaClick1 = new Carta1(this.handler,0,0,0);
	

	public Player(Handler handler, float x, float y) {
		super(handler, x, y, 48, 72);
		
		bounds.x = 9;
		bounds.y = 42;
		bounds.width = 32;
		bounds.height = 32;
		//
		animationUp = new Animation(200, Assets.player_up);
		animationLeft = new Animation(200, Assets.player_left);
		animationDown = new Animation(200, Assets.player_down);
		animationRight = new Animation(200, Assets.player_right);
		
		
	}

	
	public void tick() {
		//
		animationUp.tick();
		animationLeft.tick();
		animationDown.tick();
		animationRight.tick();
		/*
		for(Entity i :handler.getWorld().getEntityManager().getEntities()){
			System.out.println("soy una carta"+i.getX());
		}
		*/
		//
		getInput();
		move();
		handler.getGameCamera().centerOnEntity(this);
		float playerX= handler.getWorld().getEntityManager().getPlayer().x;
		float playerY = handler.getWorld().getEntityManager().getPlayer().y;
		//System.out.println(playerX);
		//System.out.println(playerY);
		
		
	}
	
	private void getInput(){
		xMove=0;
		yMove=0;
		pegarX=0;
		pegarY=0;
		
		if(handler.getKeyManager().up)
			yMove= -speed;
		if(handler.getKeyManager().down)
			yMove=  speed;
		if(handler.getKeyManager().left)
			xMove= -speed;
		if(handler.getKeyManager().right)
			xMove= speed;
		if(handler.getKeyManager().q){
			for (int j = handler.getWorld().getEntityManager().getEntities().size()-1; j >=0;  j--) {
				Entity i = handler.getWorld().getEntityManager().getEntities().get(j);	
				if ((i.getX() < handler.getWorld().getEntityManager().getPlayer().x &&
						i.getX()+i.getWidth() > handler.getWorld().getEntityManager().getPlayer().x )
						
						&&( i.getY() < handler.getWorld().getEntityManager().getPlayer().y && i.getY() + i.getHeight() > handler.getWorld().getEntityManager().getPlayer().y )){
					
					System.out.println("carta" + i.getX() + " " + i.getY());
					System.out.println(""+j);
					id = j;
					cartaClick1 = i.getThis();
					
					comparar(j, cartaClick1);
					//parejas();
					
					
				
				}
				
			}
			
			
			
		}
			
	}

	
	public void render(Graphics g) {
		g.drawImage(getCurrentAnimationFrame(), (int)(x- handler.getGameCamera().getxOffset()), (int)(y - handler.getGameCamera().getyOffset()), width, height, null);
		//g.setColor(Color.green);
		g.fillRect((int)(x+ bounds.x - handler.getGameCamera().getxOffset()), 
				(int)(y+ bounds.y - handler.getGameCamera().getyOffset()), bounds.width, bounds.height);
		
	}
	
	private BufferedImage getCurrentAnimationFrame(){
		if(xMove<0 ) {//left
			return animationLeft.getCurrentFrame();
		}else if (xMove>0){
			return animationRight.getCurrentFrame();
		} else if (yMove< 0){
			return animationUp.getCurrentFrame();
		} else if (yMove> 0){
			return animationDown.getCurrentFrame();
			
		}else{
			return Assets.player;
		}
	}
	
	public void comparar(int id, Entity carta2){
	id= this.id;	
	
	switch(id){
	case 0: carta2.setColor(Color.blue); System.out.println("Se cambio de color");
		break;
	case 1: carta2.setColor(Color.gray);
		break ;
	case 2: carta2.setColor(Color.blue);
		break ;
	case 3: carta2.setColor(Color.MAGENTA);
		break ;
	case 4: carta2.setColor(Color.white);
		break ;
	case 5: carta2.setColor(Color.pink);
		break ;
	case 6: carta2.setColor(Color.red);
		break ;
	case 7: carta2.setColor(Color.gray);
		break ;
	case 8: carta2.setColor(Color.MAGENTA);
		break ;
	case 9: carta2.setColor(Color.pink);
		break ;
	case 10: carta2.setColor(Color.white);
		break ;
	case 11: carta2.setColor(Color.cyan);
		break ;
	case 12: carta2.setColor(Color.red);
		break ;
	case 13: carta2.setColor(Color.yellow);
		break ;
	case 14: carta2.setColor(Color.DARK_GRAY);
		break ;
	case 15: carta2.setColor(Color.GREEN);
		break ;
	case 16: carta2.setColor(Color.DARK_GRAY);
		break ;
	case 17: carta2.setColor(Color.cyan);
		break ;
	case 18: carta2.setColor(Color.GREEN);
		break ;
	case 19: carta2.setColor(Color.yellow);
		break ;
	}
	/*if(!(carta2.getColor()==carta3.getColor())){
		carta2.setColor(Color.BLACK);
	
	}*/
	}
	
	
	public void compararCartas(int x, int y, Color color, String mensaje){
		Entity auxCarta1 = handler.getWorld().getEntityManager().getEntities().get(x).getThis();
		Entity auxCarta2 = handler.getWorld().getEntityManager().getEntities().get(y).getThis();
		if(auxCarta1.getColor()==color && auxCarta2.getColor()==color){
			JOptionPane.showMessageDialog(null, mensaje);
		}
	}
	
	public void parejas(){
		compararCartas(0, 2, Color.blue , "Creador El patr�n creador nos ayuda a identificar qui�n debe ser el responsable de la creaci�n (o instanciaci�n) de nuevos objetos o clases.");
		compararCartas(1, 7, Color.gray, "Abstract factory: proporciona una interfaz para crear familias de objetos que dependen entre si.");
		compararCartas(3, 8, Color.MAGENTA, "Bridge: desvincula una abstracci�n de su implementaci�n de manera que ambas puedan variar de forma independiente");
		compararCartas(4, 10, Color.WHITE, "Facade: proporciona una interfaz unificada para un conjunto de interfaces");
		compararCartas(5, 9, Color.pink, "Singleton: garantiza que una clase solo tenga una instancia y proporciona un punto de acceso global a ella");
		compararCartas(6, 12, Color.red, "Iterator: proporciona un modo de acceder secuencialmente a los elementos de un objeto agregado sin exponer su representaci�n");
		compararCartas(11, 17, Color.cyan, "State: permite que objeto modifique su comportamiento cada vez que cambia su estado interno");
		compararCartas(13, 19, Color.yellow, "Visitor: representa una operaci�n sobre los elementos de una estructura de objetos, permite definir una nueva operaci�n sin cambiar las clases");
		compararCartas(15, 18, Color.GREEN, "Proxy: proporciona un sustituto o representante de otro objeto para controlar el acceso a este");
		compararCartas(14, 16, Color.DARK_GRAY, "Prototype: especifica los tipos de objetos a crear por medio de una instancia prototipica y crear nuevos objetos copiando este prototipo");
	
	}
	
		
	
}
