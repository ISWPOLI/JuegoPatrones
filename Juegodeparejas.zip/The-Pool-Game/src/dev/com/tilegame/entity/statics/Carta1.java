package dev.com.tilegame.entity.statics;

import java.awt.Color;
import java.awt.Graphics;

import dev.com.tilegame.Handler;
import dev.com.tilegame.gfx.Assets;
import dev.com.tilegame.tiles.Tile;

public class Carta1 extends StaticEntity{
		
	private static final Color NULL = null;
	int id;
	public Carta1(Handler handler, float x, float y, int id) {
		super(handler, x ,y, 32, 32 );
		
		bounds.x = 40;
		bounds.y = 80;
		bounds.width = this.height;
		bounds.height = this.width;
		this.id= id;
	
	}

	@Override
	public void tick() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void render(Graphics g) {
		g.setColor(this.color);
		g.fillRect((int)x, (int)y, 80, 120);
		
		if(!(this.color == NULL)){
		g.setColor(Color.BLACK);
		}
		else{
		g.setColor(color);		
		g.fillRect((int)x, (int)y, 80, 120);}
		
		
		//g.setColor(Color.GREEN);
		g.fillRect((int)bounds.x, 
				(int)bounds.y, bounds.width, bounds.height);
		//g.drawImage(Assets.box,(int)(x-handler.getGameCamera().getxOffset()),(int) (y-handler.getGameCamera().getyOffset()),width,height,null);
		
	}
	
	public void dibujarCuadro(Color color){
	
	}
	
	public void setColor(Color color){
		this.color = color;
	}
	public Color getColor(){
		return this.color;
	}
	
	private void getInput(){
		
	}
	
	public int getID(){
		return this.id;
	}

}
