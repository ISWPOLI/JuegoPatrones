package dev.com.tilegame;

import dev.com.tilegame.gfx.GameCamera;
import dev.com.tilegame.input.KeyManager;
import dev.com.tilegame.input.MousesManager;
import dev.com.tilegame.world.World;

public class Handler {
	
	private Game game;
	private World world;
	
	public Handler (Game game){
		this.game = game;
	}
	
	public int getWidth(){
		return game.getWidth();
	}
	public int getHeight(){
		return game.getHeight();
	}
	
	public KeyManager getKeyManager(){
		return game.getKeyManager();
	}
	
	public MousesManager getMouseManager(){
		return game.getMouseManager();
	}
	
	public GameCamera getGameCamera(){
		return game.getGameCamera();
	}
	
	public Game getGame() {
		return game;
	}

	public void setGame(Game game) {
		this.game = game;
	}

	public World getWorld() {
		return world;
	}

	public void setWorld(World world) {
		this.world = world;
	}

}
