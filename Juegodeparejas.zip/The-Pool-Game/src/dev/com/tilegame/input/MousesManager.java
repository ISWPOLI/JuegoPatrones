package dev.com.tilegame.input;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class MousesManager  implements MouseListener{
	
	
	public int mouseX, mouseY;
	public void tick(){
		
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		System.out.println("clicked");
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		System.out.println("pressed " + e.getX() + "" + e.getY());
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		System.out.println("release");
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
	
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
	}

}
