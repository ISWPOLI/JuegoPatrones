package dev.com.tilegame.tiles;

import dev.com.tilegame.gfx.Assets;

public class Bluefloor extends Tile{
	
	public Bluefloor (int id){
		super(Assets.bluefloor, id);
	}

}
