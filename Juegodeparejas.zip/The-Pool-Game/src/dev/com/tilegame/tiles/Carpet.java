package dev.com.tilegame.tiles;

import java.awt.image.BufferedImage;

import dev.com.tilegame.gfx.Assets;

public class Carpet extends Tile{

	public Carpet(int id) {
		super(Assets.carpet, id);
		// TODO Auto-generated constructor stub
	}

}
