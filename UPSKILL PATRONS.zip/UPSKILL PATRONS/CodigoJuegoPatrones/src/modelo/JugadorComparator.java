package modelo;
import java.util.Comparator;

public class JugadorComparator implements Comparator{
	@Override
	public int compare(Object o1, Object o2) {
		Jugador c1 = (Jugador) o1;
		Jugador c2 = (Jugador) o2;
		if(c2.getAciertos() == c1.getAciertos()){
			return c1.getNombre().compareTo(c2.getNombre());
		}
		return c2.getAciertos()-c1.getAciertos();
	}
}