package modelo;

public class Jugador {

	private String nombre;
	private int aciertos;
	
	public Jugador(String n, int a) {
		this.nombre = n;
		this.aciertos = a;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return aciertos+"  -  "+nombre;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getAciertos() {
		return aciertos;
	}
	public void setAciertos(int aciertos) {
		this.aciertos = aciertos;
	}
}
