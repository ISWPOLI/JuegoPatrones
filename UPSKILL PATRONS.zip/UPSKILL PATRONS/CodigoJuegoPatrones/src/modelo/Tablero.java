package modelo;

public class Tablero {
	
	private String[][] tablero;
	
	public Tablero(){
		tablero = new String[20][20];
	}
	
	public void inicializarTablero() {
		for (int i = 0; i < tablero.length; i++) {
			for (int j = 0; j < tablero.length; j++) {
				tablero[i][j] = " * ";
			}
		}
	}

	public String[][] getTablero() {
		return tablero;
	}
	public void setTablero(String[][] tablero) {
		this.tablero = tablero;
	}
}
