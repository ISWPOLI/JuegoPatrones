package modelo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collections;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;

public class Juego {

	private static final String tab1 = "Tableros/Tablero1.txt";
	private static final String tab2 = "Tableros/Tablero2.txt";
	private static final String tab3 = "Tableros/Tablero3.txt";
	
	private Jugador jugador;
	private Tablero tablero;
	private int nivel;
	private ArrayList<String> preguntas;
	private ArrayList<Jugador> puntajes;
	
	public Juego(Jugador j, Tablero t){
		this.jugador = j;
		this.tablero = t;
		this.nivel = 1;
		this.puntajes = new ArrayList<Jugador>();
		this.preguntas = new ArrayList<String>();
		cargarPuntajes();
		cargarPreguntas();
		
	}
	public Juego() {
		this.puntajes = new ArrayList<Jugador>();
		cargarPuntajes();
	}

	public void imprimirTablero() {
		String[][] t = tablero.getTablero();
		for (int i = 0; i < t.length; i++) {
			for (int j = 0; j < t.length; j++) {
				System.out.print(t[i][j]);
			}
			System.out.println("");
		}
	}
	public void cargarArchivo(int tab){
		File archivo = null;
		String[][] t = new String[20][20]; 
		String[] prov = null;
		int fila = 0;
		try {
			if(tab == 1){
				archivo = new File(tab1);
			}else if(tab == 2){
				archivo = new File(tab2);
			}else if(tab == 3){
				archivo = new File(tab3);
			}
			BufferedReader lector = new BufferedReader(new FileReader(archivo));
			String linea = "";
			while ((linea = lector.readLine()) != null) {
				prov=linea.split(",");
				for (int col = 0; col < prov.length; col++) {
					t[fila][col]= prov[col];
				}
				fila++;
			}
			this.tablero.setTablero(t);
		} catch (FileNotFoundException e) {
			System.out.println("Archivo no encontrado!");
		} catch (IOException e) {
			System.out.println("Error de lectura!");
		}
	}
	public void cargarPuntajes() {
		File archivo = null;
		String[] prov = null;
		int fila = 0;
		try {
			archivo = new File("Archivos/puntajes.txt");
			BufferedReader lector = new BufferedReader(new FileReader(archivo));
			String linea = "";
			while ((linea = lector.readLine()) != null) {				
				prov = linea.split(",");
				if(validarPuntaje(prov[0])){
					Jugador j = new Jugador(prov[0], Integer.parseInt(prov[1]));
					this.puntajes.add(j);
				}
			}
		} catch (FileNotFoundException e) {
			System.out.println("Archivo no encontrado!");
		} catch (IOException e) {
			System.out.println("Error de lectura!");
		}
	}
	public void guardarPuntajes(){
		PrintWriter dataBase = null;
		try {
			dataBase = new PrintWriter("./Archivos/puntajes.txt");
			for (int i = 0; i < puntajes.size(); i++) {
				dataBase.println(puntajes.get(i).getNombre().toUpperCase()+","+puntajes.get(i).getAciertos());
			}
			dataBase.flush();
		} catch (FileNotFoundException e) {
			System.out.println("ERROR!");
		} finally {
			dataBase.close();
		}
	}
	public boolean validarPuntaje(String nombre) {
		for (int i = 0; i < puntajes.size(); i++) {
			if(puntajes.get(i).getNombre().equals(nombre)){
				return false;
			}
		}
		return true;
	}
	public void cargarPreguntas() {
		File archivo = null;
		String[] prov = null;
		try {
			archivo = new File("Archivos/preguntas.txt");
			BufferedReader lector = new BufferedReader(new FileReader(archivo));
			String linea = "";
			while ((linea = lector.readLine()) != null) {
				this.preguntas.add(linea);
			}
		} catch (FileNotFoundException e) {
			System.out.println("Archivo no encontrado!");
		} catch (IOException e) {
			System.out.println("Error de lectura!");
		}
	}
	public void agregarPuntaje(Jugador j){
		puntajes.add(j);
	}
	public Jugador getJugador() {
		return jugador;
	}
	public void setJugador(Jugador jugador) {
		this.jugador = jugador;
	}
	public Tablero getTablero() {
		return tablero;
	}
	public void setTablero(Tablero tablero) {
		this.tablero = tablero;
	}
	public ArrayList<Jugador> getPuntajes() {
		return puntajes;
	}
	public void setPuntajes(ArrayList<Jugador> puntajes) {
		this.puntajes = puntajes;
	}
	public ArrayList<String> getPreguntas() {
		return preguntas;
	}
	public void setPreguntas(ArrayList<String> preguntas) {
		this.preguntas = preguntas;
	}

	public int getNivel() {
		return nivel;
	}
	public void setNivel(int nivel) {
		this.nivel = nivel;
	}
}
