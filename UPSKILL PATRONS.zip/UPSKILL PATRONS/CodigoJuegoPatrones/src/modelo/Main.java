package modelo;

import GUI.VentanaIni;
import GUI.VentanaTablero;

public class Main {
	public static void main(String[] args) {
		
		new VentanaIni();		
	}
}
