package GUI;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Collections;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

import modelo.Juego;
import modelo.Jugador;
import modelo.JugadorComparator;
import modelo.Tablero;

public class VentanaTablero extends JFrame implements ActionListener{
	
	JPanel panelPrincipal, panelInfo;
	JLabel lblNivel, labelAciertos;
	JButton boton, botonVolver;
	ImageIcon imagenMuros, imagenPlayer, imagenPregunta, imagenPuerta, imagenMedalla, imagenSalir;
	
	Oyente oyente;
	
	Juego juego;
	String[][] tablero;
	String nombre;
	int nivel;
	Thread hilo;
	boolean seguirHilo=false;
    boolean hiloIniciado=false;
	
	Font f = new Font(Font.DIALOG, 2, 16);
	
	public VentanaTablero(Juego j){
		super("UPSKILL PATRONS");
		
		imagenSalir = new ImageIcon("./Imagenes/"+"salir.png");
		imagenMuros = new ImageIcon("./Imagenes/"+"muroA2.png");
		imagenPlayer = new ImageIcon("./Imagenes/"+"user.png");
		imagenPregunta = new ImageIcon("./Imagenes/"+"pregunta.png");
		imagenPuerta= new ImageIcon("./Imagenes/"+"puerta.png");
		imagenMedalla= new ImageIcon("./Imagenes/"+"medalla.png");
		
		this.juego = j;
		this.tablero = this.juego.getTablero().getTablero();
		this.nombre = this.juego.getJugador().getNombre();
		this.nivel= this.juego.getNivel();
		
		this.botonVolver = new JButton();
		this.botonVolver.addActionListener(this);
		this.botonVolver.setIcon(imagenSalir);
		this.botonVolver.setBackground(Color.RED);
		
		this.botonVolver.addActionListener(this);
		this.botonVolver.setActionCommand("SALIR");
		
		this.lblNivel = new JLabel("NIVEL : "+juego.getNivel(), JLabel.CENTER);
		this.lblNivel.setOpaque(true);
		this.lblNivel.setBackground(Color.BLACK);
		this.lblNivel.setForeground(Color.WHITE);
		this.lblNivel.setFont(f);
		
		this.labelAciertos = new JLabel("ACIERTOS >>> "+juego.getJugador().getAciertos());
		this.labelAciertos.setOpaque(true);
		this.labelAciertos.setBackground(Color.RED);
		this.labelAciertos.setForeground(Color.WHITE);
		this.labelAciertos.setFont(f);
		
		this.panelInfo = new JPanel();
		this.panelInfo.setLayout(new BorderLayout());
		this.panelInfo.setBackground(Color.BLACK);
		
		this.panelPrincipal = new JPanel();
		this.panelPrincipal.setLayout(new GridLayout(20, 20));
		this.panelPrincipal.setBackground(Color.WHITE);
		
		oyente = new Oyente();
		
		
		pintarTablero();
		

		this.panelInfo.add(botonVolver, BorderLayout.WEST);
		this.panelInfo.add(lblNivel, BorderLayout.CENTER);
		this.panelInfo.add(labelAciertos, BorderLayout.EAST);
		
		this.add(panelInfo, BorderLayout.NORTH);
		this.add(panelPrincipal);
		
		this.pack();
		this.setSize(500, 500);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.boton.requestFocus();
	}

	private class Oyente implements KeyListener{
		public void keyPressed(KeyEvent e) {	
			moverse(e);
		}
		public void keyReleased(KeyEvent e){
			
		}
		public void keyTyped(KeyEvent e) {
			
		}
		private void moverse(KeyEvent e) {
			int[] pos = ubicarJugador(tablero);
			if(e.getKeyCode()==KeyEvent.VK_LEFT){
				if(pos[1] > 0){
					if(tablero[pos[0]][pos[1]-1].equals("-")){
						tablero[pos[0]][pos[1]] = "-";
						tablero[pos[0]][pos[1]-1] = "J";
						pintarTablero();
						actualizarVista();
					}else if(tablero[pos[0]][pos[1]-1].equals("?")){
						tablero[pos[0]][pos[1]-1]="-";
						new VentanaPregunta(juego);
						cerrar();
					}else if(tablero[pos[0]][pos[1]-1].equals("M")){
						JOptionPane.showMessageDialog(null, "Has superado el nivel -"+nivel+"- FELICITACIONES!!!\n>>> FIN DEL JUEGO", "JUEGO SUPERADO!", JOptionPane.INFORMATION_MESSAGE);
						juego.agregarPuntaje(juego.getJugador());
						Collections.sort(juego.getPuntajes(), new JugadorComparator());
						cerrar();
						new VentanaIni();
					}
				}
			}
			if(e.getKeyCode()==KeyEvent.VK_UP){
				if(pos[0] > 0){
					if(tablero[pos[0]-1][pos[1]].equals("-")){
						tablero[pos[0]][pos[1]] = "-";
						tablero[pos[0]-1][pos[1]] = "J";
						pintarTablero();
						actualizarVista();
					}else if(tablero[pos[0]-1][pos[1]].equals("?")){
						tablero[pos[0]-1][pos[1]]="-";
						new VentanaPregunta(juego);
						cerrar();
					}else if(tablero[pos[0]-1][pos[1]].equals("M")){
						JOptionPane.showMessageDialog(null, "Has superado el nivel -"+nivel+"- FELICITACIONES!!!\n>>> NIVEL 2", "SUPERADO!", JOptionPane.INFORMATION_MESSAGE);
						juego.cargarArchivo(2);
						juego.setNivel(nivel+1);
						juego.agregarPuntaje(juego.getJugador());
						Collections.sort(juego.getPuntajes(), new JugadorComparator());
						cerrar();
						new VentanaTablero(juego);
					}
				}
			}
			if(e.getKeyCode()==KeyEvent.VK_RIGHT){
				if(pos[1] < tablero.length-1){
					if(tablero[pos[0]][pos[1]+1].equals("-")){
						tablero[pos[0]][pos[1]] = "-";
						tablero[pos[0]][pos[1]+1] = "J";
						pintarTablero();
						actualizarVista();
					}else if(tablero[pos[0]][pos[1]+1].equals("?")){
						tablero[pos[0]][pos[1]+1]="-";
						new VentanaPregunta(juego);
						cerrar();
					}else if(tablero[pos[0]][pos[1]+1].equals("M")){
						JOptionPane.showMessageDialog(null, "Has superado el nivel -"+nivel+"- FELICITACIONES!!!\n>>> NIVEL 3", "SUPERADO!", JOptionPane.INFORMATION_MESSAGE);
						juego.agregarPuntaje(juego.getJugador());
						Collections.sort(juego.getPuntajes(), new JugadorComparator());
						juego.cargarArchivo(3);
						juego.setNivel(nivel+1);
						cerrar();
						new VentanaTablero(juego);
					}
				}
			}
			if(e.getKeyCode()==KeyEvent.VK_DOWN){
				if(pos[0] < tablero.length-1){
					if(tablero[pos[0]+1][pos[1]].equals("-")){
						tablero[pos[0]][pos[1]] = "-";
						tablero[pos[0]+1][pos[1]] = "J";
						pintarTablero();
						actualizarVista();
					}else if(tablero[pos[0]+1][pos[1]].equals("?")){
						tablero[pos[0]+1][pos[1]]="-";
						new VentanaPregunta(juego);
						cerrar();
					}
				}
			}
		}
	}
	public int[] ubicarJugador(String[][] tab) {
		int[] p = new int[2];
		for (int i = 0; i < tab.length; i++) {
			for (int j = 0; j < tab.length; j++) {
				if(tab[i][j].equals("J")){
					p[0] = i;
					p[1] = j;
				}
			}
		}
		return p;
	}
	public void pintarTablero(){
		for (int i = 0; i < tablero.length; i++) {
			for (int j = 0; j < tablero.length; j++) {
				boton = new JButton();
				boton.setBorder(null);
				if(tablero[i][j].equals("|")){				// LIMITES
					boton.setBackground(Color.WHITE);
					boton.setIcon(imagenMuros);
				}else if(tablero[i][j].equals("-")){		// CAMINO
					boton.setBackground(Color.BLACK);
				}else if(tablero[i][j].equals("?")){		// PREGUNTA
					boton.setBackground(Color.WHITE);
					boton.setIcon(imagenPregunta);
				}else if(tablero[i][j].equals("J")){		// JUGADOR
					boton.setBackground(Color.BLACK);
					boton.setIcon(imagenPlayer);
				}else if(tablero[i][j].equals("P")){		// PUERTA
					boton.setBackground(Color.BLACK);
					boton.setIcon(imagenPuerta);
				}else if(tablero[i][j].equals("M")){		// LLEGADA
					boton.setBackground(Color.BLACK);
					boton.setIcon(imagenMedalla);
				}else if(tablero[i][j].equals("X")){		// PREGUNTA X
					boton.setBackground(Color.BLACK);
				}
				boton.addActionListener(this);
				boton.addKeyListener(oyente);
				this.panelPrincipal.add(boton);
				this.juego.getTablero().setTablero(tablero);
			}
		}
	}
	public void actualizarVista(){
		new VentanaTablero(juego);
		this.dispose();
	}	
	public void cerrar() {
		this.juego.guardarPuntajes();
		this.dispose();
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		Object o = e.getSource();
		if(o instanceof JButton){
			JButton b = (JButton) o;
			if(b.getActionCommand().equals("SALIR")){
				this.juego.getPuntajes().add(juego.getJugador());
				Collections.sort(juego.getPuntajes(), new JugadorComparator());
				this.juego.guardarPuntajes();
				new VentanaIni();
				this.dispose();
			}
		}
	}
}
