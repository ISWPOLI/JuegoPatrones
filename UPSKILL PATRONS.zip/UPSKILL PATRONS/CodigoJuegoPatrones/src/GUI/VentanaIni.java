package GUI;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Collections;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import modelo.Juego;
import modelo.Jugador;
import modelo.JugadorComparator;
import modelo.Tablero;

public class VentanaIni extends JFrame implements ActionListener{

	
	
	JPanel panelPrincipal, panelImagen, panelAbajo;
	JLabel labelImagen, labelNombre;
	JButton btnSalir, btnJugar, btnRanking;
	JTextField txtNombre;
	ImageIcon upskill, salir, jugar, ranking;
	
	Juego juego;
	
	Color DodgerBlue = new Color(0, 103, 255);
	Font f = new Font(Font.DIALOG, 2, 18);
	
	public VentanaIni(){
		super("UPSKILL PATRONS");
		this.panelPrincipal = new JPanel();
		this.panelPrincipal.setLayout(new GridLayout(2, 1));
		this.panelPrincipal.setBackground(Color.WHITE);
		
		this.upskill = new ImageIcon("./Imagenes/"+"logo.png");
		this.labelImagen = new JLabel();
		this.labelImagen.setIcon(upskill);
		this.labelImagen.setVerticalAlignment(JLabel.CENTER);
		
		this.panelImagen = new JPanel();
		this.panelImagen.setLayout(new BorderLayout());
		this.panelImagen.add(labelImagen, BorderLayout.CENTER);
		this.panelImagen.setBackground(Color.BLACK);
		
		this.labelNombre = new JLabel("NOMBRE");
		this.labelNombre.setBounds(190, 20, 100, 30);
		this.labelNombre.setForeground(Color.BLACK);
		this.labelNombre.setFont(f);
		
		this.txtNombre = new JTextField();
		this.txtNombre.setBounds(280, 20, 150, 30);
		this.txtNombre.setBackground(DodgerBlue);
		this.txtNombre.setForeground(Color.WHITE);
		this.txtNombre.setBorder(null);
		this.txtNombre.setFont(f);
		
		this.ranking = new ImageIcon("./Imagenes/"+"ranking.png");
		this.btnRanking = new JButton();
		this.btnRanking.setBounds(80, 70, 100, 100);
		this.btnRanking.setBackground(DodgerBlue);
		this.btnRanking.setIcon(ranking);
		this.btnRanking.setBorder(null);
		this.btnRanking.addActionListener(this);
		this.btnRanking.setActionCommand("RANKING");
		
		this.jugar = new ImageIcon("./Imagenes/"+"jugar.png");
		this.btnJugar = new JButton();
		this.btnJugar.setBounds(255, 70, 100, 100);
		this.btnJugar.setBackground(DodgerBlue);
		this.btnJugar.setIcon(jugar);
		this.btnJugar.setBorder(null);
		this.btnJugar.addActionListener(this);
		this.btnJugar.setActionCommand("JUGAR");
		
		this.salir = new ImageIcon("./Imagenes/"+"salida.png");
		this.btnSalir = new JButton();
		this.btnSalir.setBounds(425, 70, 100, 100);
		this.btnSalir.setBackground(DodgerBlue);
		this.btnSalir.setIcon(salir);
		this.btnSalir.setBorder(null);
		this.btnSalir.addActionListener(this);
		this.btnSalir.setActionCommand("SALIR");
		
		this.panelAbajo = new JPanel();
		this.panelAbajo.setLayout(null);
		this.panelAbajo.setBackground(Color.WHITE);
		
		this.panelAbajo.add(labelNombre, SwingConstants.CENTER);
		this.panelAbajo.add(txtNombre);
		this.panelAbajo.add(btnSalir);
		this.panelAbajo.add(btnJugar);
		this.panelAbajo.add(btnRanking);
		
		this.panelPrincipal.add(panelImagen);
		this.panelPrincipal.add(panelAbajo);
		
		this.add(panelPrincipal);
		
		this.setSize(610, 400);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		Object o = e.getSource();
		if(o instanceof JButton){
			JButton b = (JButton) o;
			if(b.getActionCommand().equals("SALIR")){
				this.dispose();
				
			}else if(b.getActionCommand().equals("JUGAR")){
				if(!txtNombre.getText().isEmpty()){
					Jugador jugador = new Jugador(txtNombre.getText().toUpperCase(), 0);
					Tablero tablero = new Tablero();
					juego = new Juego(jugador, tablero);
					juego.cargarArchivo(1);
					new VentanaTablero(juego);					
					this.dispose();
				}else{
					JOptionPane.showMessageDialog(null, "Para jugar, INGRESE SU NOMBRE!", "ERROR", JOptionPane.ERROR_MESSAGE);
				}
				
			}else if(b.getActionCommand().equals("RANKING")){
				juego = new Juego();
				juego.guardarPuntajes();
				juego.cargarPuntajes();
				new VentanaRanking(juego);
			} 
		}
	}
	
}
