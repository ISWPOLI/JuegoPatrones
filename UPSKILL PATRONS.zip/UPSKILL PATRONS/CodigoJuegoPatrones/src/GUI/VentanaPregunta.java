package GUI;

import java.awt.Color;
import java.awt.ComponentOrientation;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import modelo.Juego;
import modelo.JugadorComparator;

public class VentanaPregunta extends JFrame implements ActionListener{

	JPanel panelPrincipal, panelPregunta, panelRespuestas;
	JTextArea txtPregunta;
	JButton botR1, botR2, botR3, botR4; 
	
	Juego juego;
	String[][] t;
	ArrayList<String> p;
	String[] prov;
	String pregunta, r1, r2, r3, r4, r;
	
	Font f = new Font(Font.DIALOG, 2, 20);
	
	public VentanaPregunta(Juego j){
		this.juego = j;
		this.p = new ArrayList<String>();
		this.p = j.getPreguntas();
		t = this.juego.getTablero().getTablero();
		
		prov = seleccionarPregunta().split("/"); 
		pregunta = prov[0];
		r1 = prov[1];
		r2 = prov[2];
		r3 = prov[3];
		r4 = prov[4];
		r = prov[5];
		
		this.panelPrincipal = new JPanel();
		this.panelPrincipal.setLayout(new GridLayout(2, 1));
		
		this.txtPregunta = new JTextArea();
		this.txtPregunta.setText("\n > "+pregunta);
		this.txtPregunta.setLineWrap(true);
		this.txtPregunta.setFont(f);
		
		this.botR1 = new JButton();
		this.botR1.setText(r1);
		this.botR1.setActionCommand(r1);
		this.botR1.setBackground(Color.BLACK);
		this.botR1.setForeground(Color.WHITE);
		this.botR1.addActionListener(this);
		
		
		this.botR2 = new JButton();
		this.botR2.setText(r2);
		this.botR2.setActionCommand(r2);
		this.botR2.setBackground(Color.BLACK);
		this.botR2.setForeground(Color.WHITE);
		this.botR2.addActionListener(this);
		
		this.botR3 = new JButton();
		this.botR3.setText(r3);
		this.botR3.setActionCommand(r3);
		this.botR3.setBackground(Color.BLACK);
		this.botR3.setForeground(Color.WHITE);
		this.botR3.addActionListener(this);
		
		this.botR4 = new JButton();
		this.botR4.setText(r4);
		this.botR4.setActionCommand(r4);
		this.botR4.setBackground(Color.BLACK);
		this.botR4.setForeground(Color.WHITE);
		this.botR4.addActionListener(this);
		
		this.panelRespuestas = new JPanel();
		this.panelRespuestas.setLayout(new GridLayout(4, 1));
		this.panelRespuestas.setBackground(Color.BLACK);
		this.panelRespuestas.add(botR1);
		this.panelRespuestas.add(botR2);
		this.panelRespuestas.add(botR3);
		this.panelRespuestas.add(botR4);
		
		this.panelPrincipal.add(txtPregunta);
		this.panelPrincipal.add(panelRespuestas);
		
		this.add(panelPrincipal);
		
		this.pack();
		
		this.setSize(600, 300);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
	}

	public String seleccionarPregunta() {
		// TODO Auto-generated method stub
		Random r = new Random();
		String s="";
		int ale;
		while(s.isEmpty()){
			ale = r.nextInt(p.size());
			if(!p.get(ale).contains("�")){
				s=p.get(ale);
				p.set(ale, p.get(ale)+"�");
			}
		}
		return s;
	}
	public boolean eliminarPuerta() {
		boolean elimino = false;
		int i = t.length-1;
		int j = 0;
		while(i >= 0 && !elimino){
			j=0;
			while(j < t.length  && !elimino){
				if(t[i][j].equals("P")){
					t[i][j]="-";
					elimino = true;
				}
				j++;
			}
			i=i-1;
		}
		this.juego.getTablero().setTablero(t);
		return elimino;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		Object o = e.getSource();
		if(o instanceof JButton){
			JButton b = (JButton) o;
			if(b.getActionCommand().equals(r)){
				b.setBackground(Color.BLUE);
				JOptionPane.showMessageDialog(null, "Respuesta correcta", "CORRECTO", JOptionPane.INFORMATION_MESSAGE);
				if(eliminarPuerta()){
					this.juego.getJugador().setAciertos(juego.getJugador().getAciertos()+1);
				}
				juego.agregarPuntaje(juego.getJugador());
				Collections.sort(juego.getPuntajes(), new JugadorComparator());
				this.juego.guardarPuntajes();
				new VentanaTablero(juego);
				this.dispose();
			}else{
				b.setBackground(Color.RED);
				if(botR1.getActionCommand().equals(r)){
					botR1.setBackground(Color.BLUE);
				}else if(botR2.getActionCommand().equals(r)){
					botR2.setBackground(Color.BLUE);
				}else if(botR3.getActionCommand().equals(r)){
					botR3.setBackground(Color.BLUE);
				}else if(botR4.getActionCommand().equals(r)){
					botR4.setBackground(Color.BLUE);
				}
				JOptionPane.showMessageDialog(null, "Respuesta INCORRECTA!!!", "ERROR", JOptionPane.ERROR_MESSAGE);
				new VentanaTablero(juego);
				this.dispose();
			}
		}
	}
}
