package GUI;

import java.awt.Color;

import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import modelo.Juego;

public class VentanaRanking extends JFrame{

	JPanel panelPrincipal;
	JLabel labelRanking;
	JList<String> listaRanking;
	DefaultListModel<String> dlmRanking;
	JScrollPane scrollRanking;
	ImageIcon imgRank, imgVolver;
	
	Juego juego;
	
	public VentanaRanking(Juego j){
		super("UPSKILL PATRONS");
		
		this.juego = j;
		
		this.imgRank = new ImageIcon("./Imagenes/"+"lblRanking.png");
		
		this.panelPrincipal = new JPanel();
		this.panelPrincipal.setLayout(null);
		this.panelPrincipal.setBackground(Color.BLACK);
		
		this.labelRanking = new JLabel();
		this.labelRanking.setIcon(imgRank);
		this.labelRanking.setBounds(20, 10, 230, 70);
		
		this.listaRanking= new JList<String>();
		this.dlmRanking= new DefaultListModel<String>();
		for (int i = 0; i < j.getPuntajes().size(); i++) {
			dlmRanking.add(i, j.getPuntajes().get(i).toString());
		}
		this.listaRanking.setModel(dlmRanking);
		this.scrollRanking= new JScrollPane(listaRanking);
		this.scrollRanking.setBounds(20, 90, 230, 200);
		
		this.panelPrincipal.add(labelRanking);
		this.panelPrincipal.add(scrollRanking);
		
		this.add(panelPrincipal);
		
		this.setSize(275, 340);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		this.setVisible(true);
		
	}
}
